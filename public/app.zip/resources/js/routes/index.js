import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

import ExampleComponent from '../components/ExampleComponent'
import TwoComponent from '../components/TwoComponent'


export default new Router({
    mode: 'history',
    routes: [
        {
            path: '/',
            component: ExampleComponent,
            name: 'User Timeline Page',
        },
        {
            path: '/two',
            component: TwoComponent,
            name: 'My Timeline Page',
        },
    ],
});
